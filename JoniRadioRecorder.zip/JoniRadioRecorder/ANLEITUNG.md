# Radio Recorder für Joni – Anleitung

Diese App nimmt das Lied auf, das gerade auf dem Handy läuft (z.B. ein Radio-Stream). Bedienung: **Aufnahme starten**, **Aufnahme stoppen**, **Letzte Aufnahme abspielen**. Jede Aufnahme wird als eigene Datei im Ordner **Music/JoniRadio** auf dem Handy gespeichert.

Wichtig: Die Dateien sind im **WAV-Format** (nicht MP3) – das ist für die App technisch einfacher, klingt aber identisch und lässt sich von der Sendeplaner-App genauso abspielen.

Da hier keine fertige Datei gebaut werden kann, läuft der Bau der App automatisch über GitHub (kostenlos). Hier die Schritte:

## 1. GitHub-Konto erstellen

1. Gehe auf https://github.com/signup
2. Lege einen kostenlosen Account an (E-Mail, Passwort, Benutzername).

## 2. Neues Repository erstellen

1. Nach dem Einloggen oben rechts auf das **+** klicken → **New repository**.
2. Name eingeben, z.B. `joni-radio-recorder`.
3. Sichtbarkeit: **Public** (reicht völlig aus).
4. Auf **Create repository** klicken.

## 3. Projektdateien hochladen

1. Im neuen, leeren Repository auf **uploading an existing file** klicken (Link in der Mitte der Seite).
2. Den kompletten Inhalt des Ordners `JoniRadioRecorder` (alle Dateien und Unterordner: `app`, `.github`, `build.gradle.kts`, `settings.gradle.kts`, usw.) per Drag & Drop in das Browserfenster ziehen.
   - Tipp: Den `JoniRadioRecorder`-Ordner am besten lokal entpacken/öffnen und **den Inhalt** (nicht den Ordner selbst) auswählen, damit `app`, `.github` usw. direkt im Repository landen.
3. Unten auf **Commit changes** klicken.

## 4. Build automatisch starten lassen

1. Sobald die Dateien hochgeladen sind, oben im Repository auf den Reiter **Actions** klicken.
2. Es sollte automatisch ein Workflow **"Build APK"** starten (gelber Punkt = läuft, grünes Häkchen = fertig). Das dauert ca. 3–5 Minuten.
3. Falls nichts läuft: links auf **Build APK** klicken, dann rechts auf **Run workflow** → **Run workflow**.

## 5. APK herunterladen

1. Wenn der Workflow-Lauf fertig ist (grünes Häkchen), darauf klicken.
2. Ganz unten bei **Artifacts** erscheint **RadioRecorder-debug-apk**. Darauf klicken zum Herunterladen.
3. Es lädt eine ZIP-Datei herunter – darin liegt `app-debug.apk`.

## 6. APK auf Joni's Handy installieren

1. Die `app-debug.apk` auf Joni's Android-Handy übertragen (z.B. per E-Mail an sich selbst, Google Drive, oder USB-Kabel).
2. Auf dem Handy die Datei antippen. Android fragt eventuell nach Erlaubnis, **Apps aus dieser Quelle zu installieren** – das einmalig zulassen.
3. Installieren antippen, dann **Öffnen**.

**Hinweis:** Die App benötigt **Android 10 oder neuer**.

## 7. Benutzung

1. App öffnen. Beim ersten Mal Berechtigungen erlauben:
   - **Mikrofon** (wird vom System verlangt, auch wenn das eigentliche Audio nicht über das Mikrofon läuft)
   - **Benachrichtigungen**
2. Auf **"Aufnahme starten"** tippen. Android zeigt dann ein Systemfenster ("Aufnahme starten?" / "Diese App beginnt mit der Aufnahme..."). Hier auf **"Starten"** bzw. **"Jetzt starten"** tippen – das erscheint bei **jedem** Drücken von "Aufnahme starten" erneut, das ist normal.
3. Wenn das Lied vorbei ist: **"Aufnahme stoppen"** drücken. Die Aufnahme wird gespeichert und erscheint in der Liste unten.
4. Mit **"Letzte Aufnahme abspielen"** oder durch Antippen eines Eintrags in der Liste kann die Aufnahme angehört werden.

## 8. Dateien zur Sendeplaner-App bringen

Die Aufnahmen liegen im Ordner **Music/JoniRadio** auf dem Handy (sichtbar über jede Datei-Manager-App, z.B. "Dateien" von Google).

Von dort können sie auf den PC kopiert werden (USB-Kabel, Google Drive, etc.), in den Ordner, in dem die Sendeplaner-App (RRO_Sendeplaner.html) liegt – und dort dann in die Sendeliste eingetragen werden.
