package com.harald.joniradiorecorder

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.media.MediaPlayer
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.widget.ArrayAdapter
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.harald.joniradiorecorder.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var projectionManager: MediaProjectionManager

    private var isRecording = false
    private var mediaPlayer: MediaPlayer? = null

    private val recordings = mutableListOf<RecordingItem>()
    private lateinit var adapter: ArrayAdapter<String>

    // Schritt 2: System-Audio-Aufnahme erlauben (Bildschirm-/Audioaufnahme-Dialog)
    private val screenCaptureLauncher: ActivityResultLauncher<Intent> =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == RESULT_OK && result.data != null) {
                startRecordingService(result.resultCode, result.data!!)
            } else {
                binding.statusText.text = getString(R.string.status_permission_denied)
            }
        }

    // Schritt 1: Mikrofon- (und ggf. Benachrichtigungs-)Berechtigung
    private val permissionLauncher: ActivityResultLauncher<Array<String>> =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { results ->
            val micGranted = results[Manifest.permission.RECORD_AUDIO] == true ||
                ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) ==
                PackageManager.PERMISSION_GRANTED
            if (micGranted) {
                requestScreenCapture()
            } else {
                binding.statusText.text = getString(R.string.status_mic_permission_needed)
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        projectionManager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager

        adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, mutableListOf())
        binding.recordingsList.adapter = adapter

        binding.recordButton.setOnClickListener { onRecordClicked() }
        binding.stopButton.setOnClickListener { onStopClicked() }
        binding.playButton.setOnClickListener { onPlayLastClicked() }

        binding.recordingsList.setOnItemClickListener { _, _, position, _ ->
            playRecording(recordings[position].uri)
        }

        updateButtons()
        loadRecordings()
    }

    override fun onResume() {
        super.onResume()
        if (!isRecording) {
            loadRecordings()
        }
    }

    private fun onRecordClicked() {
        val needed = mutableListOf<String>()

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED
        ) {
            needed.add(Manifest.permission.RECORD_AUDIO)
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            needed.add(Manifest.permission.POST_NOTIFICATIONS)
        }

        if (needed.isNotEmpty()) {
            permissionLauncher.launch(needed.toTypedArray())
        } else {
            requestScreenCapture()
        }
    }

    private fun requestScreenCapture() {
        screenCaptureLauncher.launch(projectionManager.createScreenCaptureIntent())
    }

    private fun startRecordingService(resultCode: Int, data: Intent) {
        val serviceIntent = Intent(this, RecordingService::class.java).apply {
            action = RecordingService.ACTION_START
            putExtra(RecordingService.EXTRA_RESULT_CODE, resultCode)
            putExtra(RecordingService.EXTRA_RESULT_DATA, data)
        }
        ContextCompat.startForegroundService(this, serviceIntent)

        isRecording = true
        updateButtons()
        binding.statusText.text = getString(R.string.status_recording)
    }

    private fun onStopClicked() {
        val serviceIntent = Intent(this, RecordingService::class.java).apply {
            action = RecordingService.ACTION_STOP
        }
        startService(serviceIntent)

        isRecording = false
        updateButtons()
        binding.statusText.text = getString(R.string.status_saved)

        // Kurze Verzögerung, damit der Service die Datei fertig speichern kann,
        // bevor wir die Liste neu laden.
        binding.recordingsList.postDelayed({ loadRecordings() }, 800)
    }

    private fun onPlayLastClicked() {
        if (recordings.isNotEmpty()) {
            playRecording(recordings.first().uri)
        } else {
            binding.statusText.text = getString(R.string.status_no_recordings)
        }
    }

    private fun playRecording(uri: Uri) {
        mediaPlayer?.release()
        mediaPlayer = MediaPlayer().apply {
            setDataSource(this@MainActivity, uri)
            setOnCompletionListener { it.release() }
            prepare()
            start()
        }
    }

    private fun loadRecordings() {
        recordings.clear()
        recordings.addAll(RecordingsRepository.list(this))

        adapter.clear()
        adapter.addAll(recordings.map { it.displayName })
        adapter.notifyDataSetChanged()
    }

    private fun updateButtons() {
        binding.recordButton.isEnabled = !isRecording
        binding.stopButton.isEnabled = isRecording
    }

    override fun onDestroy() {
        mediaPlayer?.release()
        mediaPlayer = null
        super.onDestroy()
    }
}
