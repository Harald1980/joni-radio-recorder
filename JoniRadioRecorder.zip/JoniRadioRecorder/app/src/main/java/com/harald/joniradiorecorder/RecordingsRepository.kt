package com.harald.joniradiorecorder

import android.content.Context
import android.net.Uri
import android.provider.MediaStore

data class RecordingItem(val uri: Uri, val displayName: String)

object RecordingsRepository {

    // Aufnahmen werden hier abgelegt: Musik/JoniRadio
    const val RELATIVE_PATH = "Music/JoniRadio"

    fun list(context: Context): List<RecordingItem> {
        val items = mutableListOf<RecordingItem>()
        val collection = MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)

        val projection = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.DISPLAY_NAME,
            MediaStore.Audio.Media.DATE_ADDED
        )

        val selection = "${MediaStore.Audio.Media.RELATIVE_PATH} = ?"
        val selectionArgs = arrayOf("$RELATIVE_PATH/")
        val sortOrder = "${MediaStore.Audio.Media.DATE_ADDED} DESC"

        context.contentResolver.query(
            collection,
            projection,
            selection,
            selectionArgs,
            sortOrder
        )?.use { cursor ->
            val idCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
            val nameCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DISPLAY_NAME)
            while (cursor.moveToNext()) {
                val id = cursor.getLong(idCol)
                val name = cursor.getString(nameCol)
                val uri = MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY, id)
                items.add(RecordingItem(uri, name))
            }
        }
        return items
    }
}
